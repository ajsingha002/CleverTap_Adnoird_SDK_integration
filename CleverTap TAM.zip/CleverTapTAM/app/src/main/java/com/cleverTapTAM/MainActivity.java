package com.cleverTapTAM;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Bundle;

import android.support.design.widget.Snackbar;
import com.clevertap.android.sdk.CleverTapAPI;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_READ_STATE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CleverTapAPI cleverTapAPI = CleverTapAPI.getDefaultInstance(getApplicationContext());
        cleverTapAPI.createNotificationChannel(getApplicationContext(),"1","CleverTap TAM","Test Description", NotificationManager.IMPORTANCE_MAX,true);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            // We do not have this permission. Let's ask the user
            helloTextView.setText("No Permission");
            Snackbar snackbar = Snackbar
                    .make(coordinatorLayout, "www.journaldev.com", Snackbar.LENGTH_LONG);
            snackbar.show();
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, PERMISSION_READ_STATE);
        } else {
            helloTextView.setText("Got Permission");
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        final TextView helloTextView = (TextView) findViewById(R.id.welcomeText);
        switch (requestCode) {
            case PERMISSION_READ_STATE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    helloTextView.setText("Got Permission - Checked");
                    // permission granted!
                    // you may now do the action that requires this permission
                } else {
                    // permission denied
                    helloTextView.setText("No Permission - Checked");
                }
                return;
            }
        }
    }
}